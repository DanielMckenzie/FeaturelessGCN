import numpy as np
import random
import sys
from sklearn import datasets
import pickle as pkl
import scipy.sparse as sp
import torch
import networkx as nx
from sklearn import preprocessing
import pickle
import torch
from torch.autograd import Variable

#pikd = open("ind.citeseer.graph", 'rb') 
#data = pickle.load(pikd) 
#ects.append(pkl.load(data))




with open("ind.cora.ty", 'rb') as f:
     objects.append(pickle.load(f))

#with open("sparse_matrix.npz", 'rb') as f:
 #    objects.append(pickle.load(f))

